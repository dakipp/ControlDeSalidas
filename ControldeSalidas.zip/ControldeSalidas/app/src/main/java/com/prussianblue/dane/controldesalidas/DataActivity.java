

package com.prussianblue.dane.controldesalidas;

import android.content.DialogInterface;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.provider.SyncStateContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;

public class DataActivity extends AppCompatActivity {
    public TextView tvDate;
    public EditText txtPrevio;
    public EditText txtSalida;
    public EditText txtEntrada;
    public EditText txtDomicilio;
    public EditText txtAfeccion;
    public EditText txtACargo;
    public EditText txtChofer;
    public EditText txtMovil;
    public Button btnAnadirMas;
    public Button btnAnadirTerminar;
    SQLiteHelper helper = new SQLiteHelper(DataActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        tvDate = (TextView)findViewById(R.id.tvDate);
        String dispDate = new SimpleDateFormat("dd-MM-yy").format(new Date());
        tvDate.setText(dispDate);

        txtPrevio = (EditText)findViewById(R.id.txtPrevio);
        txtSalida = (EditText)findViewById(R.id.txtSalida);
        txtEntrada = (EditText)findViewById(R.id.txtEntrada);
        txtDomicilio = (EditText)findViewById(R.id.txtDomicilio);
        txtAfeccion = (EditText)findViewById(R.id.txtAfeccion);
        txtACargo = (EditText)findViewById(R.id.txtACargo);
        txtChofer = (EditText)findViewById(R.id.txtChofer);
        txtMovil = (EditText)findViewById(R.id.txtMovil);
        btnAnadirMas = (Button)findViewById(R.id.btnAnadirMas);
        btnAnadirTerminar = (Button)findViewById(R.id.btnAnadirTerminar);

        btnAnadirTerminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtPrevio.getText().toString().equals("") || txtSalida.getText().toString().equals("") ||
                        txtEntrada.getText().toString().equals("") || txtDomicilio.getText().toString().equals("") ||
                        txtAfeccion.getText().toString().equals("") ||txtACargo.getText().toString().equals("") ||
                        txtChofer.getText().toString().equals("") ||txtMovil.getText().toString().equals("")) {
                    Toast.makeText(DataActivity.this, "Missing Info", Toast.LENGTH_SHORT).show();
                }
                else if (Integer.parseInt(txtSalida.getText().toString()) < 0 ||
                        Integer.parseInt(txtSalida.getText().toString()) >2359 ||
                        Integer.parseInt(txtEntrada.getText().toString()) < 0 ||
                        Integer.parseInt(txtEntrada.getText().toString()) > 2359 ||
                        txtSalida.getText().toString().length() != 4 ||
                        txtEntrada.getText().toString().length() != 4 ||
                        Integer.parseInt(txtSalida.getText().toString().substring(2,4)) > 59 ||
                        Integer.parseInt(txtEntrada.getText().toString().substring(2,4)) > 59) {
                    Toast.makeText(DataActivity.this, "Invalid Time", Toast.LENGTH_SHORT).show();
                }
                else {
                    Fire fire = new Fire();
                    String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

                    fire.setDate(date);
                    fire.setPrevio(txtPrevio.getText().toString());
                    fire.setHoraSalida(txtSalida.getText().toString());
                    fire.setHoraEntrada(txtEntrada.getText().toString());
                    fire.setDomicilio(txtDomicilio.getText().toString());
                    fire.setAfeccion(txtAfeccion.getText().toString());
                    fire.setACargo(txtACargo.getText().toString());
                    fire.setChofer(txtChofer.getText().toString());
                    fire.setMovil(txtMovil.getText().toString());
                    helper.insertFire(fire);

                    Intent intent = new Intent(DataActivity.this, DataActivity.class);
                    startActivity(intent);
                }
            }
        });

        btnAnadirTerminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtPrevio.getText().toString().equals("") || txtSalida.getText().toString().equals("") ||
                        txtEntrada.getText().toString().equals("") || txtDomicilio.getText().toString().equals("") ||
                        txtAfeccion.getText().toString().equals("") ||txtACargo.getText().toString().equals("") ||
                        txtChofer.getText().toString().equals("") ||txtMovil.getText().toString().equals("")) {
                    Toast.makeText(DataActivity.this, "Missing Info", Toast.LENGTH_SHORT).show();
                }
                else if (Integer.parseInt(txtSalida.getText().toString()) < 0 ||
                        Integer.parseInt(txtSalida.getText().toString()) >2359 ||
                        Integer.parseInt(txtEntrada.getText().toString()) < 0 ||
                        Integer.parseInt(txtEntrada.getText().toString()) > 2359 ||
                        txtSalida.getText().toString().length() != 4 ||
                        txtEntrada.getText().toString().length() != 4 ||
                        Integer.parseInt(txtSalida.getText().toString().substring(2,4)) > 59 ||
                        Integer.parseInt(txtEntrada.getText().toString().substring(2,4)) > 59) {
                    Toast.makeText(DataActivity.this, "Invalid Time", Toast.LENGTH_SHORT).show();
                }
                else {
                    Fire fire = new Fire();
                    String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

                    fire.setDate(date);
                    fire.setPrevio(txtPrevio.getText().toString());
                    fire.setHoraSalida(txtSalida.getText().toString());
                    fire.setHoraEntrada(txtEntrada.getText().toString());
                    fire.setDomicilio(txtDomicilio.getText().toString());
                    fire.setAfeccion(txtAfeccion.getText().toString());
                    fire.setACargo(txtACargo.getText().toString());
                    fire.setChofer(txtChofer.getText().toString());
                    fire.setMovil(txtMovil.getText().toString());
                    helper.insertFire(fire);

                    Intent intent = new Intent(DataActivity.this, DisplayActivity.class);
                    startActivity(intent);
                }
            }
        });
    }
}
