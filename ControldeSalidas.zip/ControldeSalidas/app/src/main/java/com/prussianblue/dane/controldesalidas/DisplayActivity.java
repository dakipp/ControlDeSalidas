package com.prussianblue.dane.controldesalidas;

import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;

public class DisplayActivity extends AppCompatActivity {
    public ListView lvInfo;
    public TextView tvDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        SQLiteHelper helper = new SQLiteHelper(DisplayActivity.this);

        ArrayList<Fire> fires = helper.getAllRecords();

        lvInfo = (ListView) findViewById(R.id.lvInfo);
        tvDate = (TextView) findViewById(R.id.tvDate);
        String dispDate = new SimpleDateFormat("dd-MM-yy").format(new Date());
        tvDate.setText(dispDate);


        FireAdapter adapter = new FireAdapter(this, fires);
        lvInfo.setAdapter(adapter);
    }

    public void returnMain(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
