package com.prussianblue.dane.controldesalidas;

/**
 * Created by Dane on 10/29/2017.
 */

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Dane on 10/16/2017.
 */

public class FireAdapter extends BaseAdapter {
    private Context fContext;
    private LayoutInflater fInflater;
    private ArrayList<Fire> fDataSource;

    public FireAdapter(Context context, ArrayList<Fire> items) {
        fContext = context;
        fDataSource = items;
        fInflater = (LayoutInflater) fContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return fDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return fDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rowView = fInflater.inflate(R.layout.inflate_fire, parent, false);

        TextView tvNumber = (TextView)rowView.findViewById(R.id.tvNumber);
        TextView tvPrevio = (TextView)rowView.findViewById(R.id.tvPrevio);
        TextView tvTime = (TextView)rowView.findViewById(R.id.tvTime);
        TextView tvDomicilio = (TextView)rowView.findViewById(R.id.tvDomicilio);
        TextView tvAfeccion = (TextView)rowView.findViewById(R.id.tvAfeccion);
        TextView tvACargo = (TextView)rowView.findViewById(R.id.tvACargo);
        TextView tvChofer = (TextView)rowView.findViewById(R.id.tvChofer);
        TextView tvMovil = (TextView)rowView.findViewById(R.id.tvMovil);

        Fire fire = (Fire) getItem(position);
        String number = String.valueOf(getItemId(position)+1);

        String tmpSalida = fire.getHoraSalida().substring(0,2) + ":" + fire.getHoraSalida().substring(2,4);
        String tmpEntrada = fire.getHoraEntrada().substring(0,2) + ":" + fire.getHoraEntrada().substring(2,4);
        String time = tmpSalida + " - " + tmpEntrada;

        tvNumber.setText(number);
        tvPrevio.setText(fire.getPrevio());
        tvTime.setText(time);
        tvDomicilio.setText(fire.getDomicilio());
        tvAfeccion.setText(fire.getAfeccion());
        tvACargo.setText(fire.getACargo());
        tvChofer.setText(fire.getChofer());
        tvMovil.setText(fire.getMovil());

        return rowView;
    }
}

