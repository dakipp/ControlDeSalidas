package com.prussianblue.dane.controldesalidas;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import static android.content.Context.MODE_PRIVATE;


public class DateEmailFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {
    private static final String PREFS_NAME = "prefs";
    private static final String PREF_LANG = "lang";
    private static final String PREF_EMAIL = "email";

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        SharedPreferences preferences = this.getActivity().getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String pageLang = preferences.getString(PREF_LANG, "en");
        String eMail = preferences.getString(PREF_EMAIL, getString(R.string.strEmail));

        String dispDate;
        if (pageLang.equals("es")) {
            dispDate = new SimpleDateFormat("dd / MM / yyyy").format(new Date(year - 1900,month,day));
        }
        else {
            dispDate = new SimpleDateFormat("MM / dd / yyyy").format(new Date(year - 1900,month,day));
        }
        String emailDate =  new SimpleDateFormat("yyyy-MM-dd").format(new Date(year - 1900,month,day));

        SQLiteHelper helper = new SQLiteHelper(getContext());
        ArrayList<Fire> fires = helper.getRecordsForDay(emailDate);
        StringBuilder sb = new StringBuilder();
        for (int i=0; i < fires.size();i++)
        {
            Fire fire = fires.get(i);
            sb.append(fire.getPrevio());
            sb.append(" ");
            sb.append(fire.getHoraSalida());
            sb.append(" ");
            sb.append(fire.getHoraEntrada());
            sb.append(" ");
            sb.append(fire.getDomicilio());
            sb.append(" ");
            sb.append(fire.getAfeccion());
            sb.append(" ");
            sb.append(fire.getACargo());
            sb.append(" ");
            sb.append(fire.getChofer());
            sb.append(" ");
            sb.append(fire.getMovil());
            sb.append(" ");
            sb.append("\n");
        }
        String body = sb.toString();
        String report = getString(R.string.strReport) + " " + dispDate;

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("message/rfc822");
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] {eMail});
        intent.putExtra(Intent.EXTRA_SUBJECT, report);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        try {
            startActivity(Intent.createChooser(intent, getString(R.string.strSent)));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getContext(), getString(R.string.strNotSent), Toast.LENGTH_SHORT).show();
        }
    }


}
