package com.prussianblue.dane.controldesalidas;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import static android.content.Context.MODE_PRIVATE;


public class DatePickerFragment extends DialogFragment
        implements DatePickerDialog.OnDateSetListener {
    private static final String PREFS_NAME = "prefs";
    private static final String PREF_LANG = "lang";

    ListView lvInfo;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Use the current date as the default date in the picker
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        lvInfo = (ListView)getActivity().findViewById(R.id.lvInfo);

        // Create a new instance of DatePickerDialog and return it
        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        SharedPreferences preferences = this.getActivity().getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String pageLang = preferences.getString(PREF_LANG, "en");

        TextView tvDate= (TextView) getActivity().findViewById(R.id.tvDate);
        String dispDate;
        if (pageLang.equals("es")) {
            dispDate = new SimpleDateFormat("dd / MM / yyyy").format(new Date(year - 1900,month,day));
        }
        else {
            dispDate = new SimpleDateFormat("MM / dd / yyyy").format(new Date(year - 1900,month,day));
        }
        tvDate.setText(dispDate);

        int newDay;
        int newMonth;
        int newYear;

        if (pageLang=="en"){
            newMonth = Integer.valueOf(dispDate.substring(0,2));
            newDay = Integer.valueOf(dispDate.substring(5,7));
            newYear = Integer.valueOf(dispDate.substring(10));
        }
        else{
            newDay = Integer.valueOf(dispDate.substring(0,2));
            newMonth = Integer.valueOf(dispDate.substring(5,7));
            newYear = Integer.valueOf(dispDate.substring(10));
        }

        String date = newYear + "-" + newMonth + "-" + newDay;

        SQLiteHelper helper = new SQLiteHelper(this.getActivity());

        ArrayList<Fire> fires = helper.getRecordsForDay(date);

        FireAdapter adapter = new FireAdapter(this.getActivity(), fires);
        lvInfo.setAdapter(adapter);
    }
}