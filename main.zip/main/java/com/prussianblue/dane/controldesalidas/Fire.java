package com.prussianblue.dane.controldesalidas;

/**
 * Created by Dane on 10/29/2017.
 */

public class Fire {
    private String id;
    private String date;
    private String previo;
    private String hora_salida;
    private String hora_entrada;
    private String domicilio;
    private String afeccion;
    private String a_cargo;
    private String chofer;
    private String movil;

    public void setID(String id) {
        this.id = id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPrevio(String previo) {
        this.previo = previo;
    }

    public void setHoraSalida(String hora_salida) {
        this.hora_salida = hora_salida;
    }

    public void setHoraEntrada(String hora_entrada) {
        this.hora_entrada = hora_entrada;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setAfeccion(String afeccion) {
        this.afeccion = afeccion;
    }

    public void setACargo(String a_cargo) {
        this.a_cargo = a_cargo;
    }

    public void setChofer(String chofer) {
        this.chofer = chofer;
    }

    public void setMovil(String movil) {
        this.movil = movil;
    }

    public String getID() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getPrevio() {
        return previo;
    }

    public String getHoraSalida() {
        return hora_salida;
    }

    public String getHoraEntrada() {
        return hora_entrada;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getAfeccion() {
        return afeccion;
    }

    public String getACargo() {
        return a_cargo;
    }

    public String getChofer() {
        return chofer;
    }

    public String getMovil() {
        return movil;
    }
}
