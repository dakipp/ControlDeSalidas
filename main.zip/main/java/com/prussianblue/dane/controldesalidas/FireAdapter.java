package com.prussianblue.dane.controldesalidas;

/**
 * Created by Dane on 10/29/2017.
 */

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.support.annotation.ColorInt;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.PopupMenu;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Dane on 10/16/2017.
 */

public class FireAdapter extends BaseAdapter {
    private Context fContext;
    private LayoutInflater fInflater;
    private ArrayList<Fire> fDataSource;

    private static final String PREFS_NAME = "prefs";
    private static final String PREF_THEME = "theme";
    private static final String PREF_LANG = "lang";
    private static final String PREF_CITY = "city";
    private static final String PREF_COUNTRY = "country";
    private static final String PREF_EMAIL = "email";

    public FireAdapter(Context context, ArrayList<Fire> items) {
        fContext = context;
        fDataSource = items;
        fInflater = (LayoutInflater) fContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return fDataSource.size();
    }

    @Override
    public Object getItem(int position) {
        return fDataSource.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final View rowView = fInflater.inflate(R.layout.inflate_fire, parent, false);

        final TextView tvNumber = (TextView)rowView.findViewById(R.id.tvNumber);
        final TextView tvPrevio = (TextView)rowView.findViewById(R.id.tvPrevio);
        final TextView tvSalida = (TextView)rowView.findViewById(R.id.tvSalida);
        final TextView tvEntrada = (TextView)rowView.findViewById(R.id.tvEntrada);
        final TextView tvDomicilio = (TextView)rowView.findViewById(R.id.tvDomicilio);
        final TextView tvAfeccion = (TextView)rowView.findViewById(R.id.tvAfeccion);
        final TextView tvACargo = (TextView)rowView.findViewById(R.id.tvACargo);
        final TextView tvChofer = (TextView)rowView.findViewById(R.id.tvChofer);
        final TextView tvMovil = (TextView)rowView.findViewById(R.id.tvMovil);

        final TextView lblPrevio = (TextView)rowView.findViewById(R.id.lblPrevio);
        final TextView lblSalida = (TextView)rowView.findViewById(R.id.lblSalida);
        final TextView lblEntrada = (TextView)rowView.findViewById(R.id.lblEntrada);
        final TextView lblDomicilio = (TextView)rowView.findViewById(R.id.lblDomicilio);
        final TextView lblAfeccion = (TextView)rowView.findViewById(R.id.lblAfeccion);
        final TextView lblACargo = (TextView)rowView.findViewById(R.id.lblACargo);
        final TextView lblChofer = (TextView)rowView.findViewById(R.id.lblChofer);
        final TextView lblMovil = (TextView)rowView.findViewById(R.id.lblMovil);

        final Fire fire = (Fire) getItem(position);
        String number = String.valueOf(getItemId(position)+1);

        String tmpSalida = fire.getHoraSalida().substring(0,2) + ":" + fire.getHoraSalida().substring(2,4);
        String tmpEntrada = fire.getHoraEntrada().substring(0,2) + ":" + fire.getHoraEntrada().substring(2,4);

        tvNumber.setText(number);
        tvPrevio.setText(fire.getPrevio());
        tvSalida.setText(tmpSalida);
        tvEntrada.setText(tmpEntrada);
        tvDomicilio.setText(fire.getDomicilio());
        tvAfeccion.setText(fire.getAfeccion());
        tvACargo.setText(fire.getACargo());
        tvChofer.setText(fire.getChofer());
        tvMovil.setText(fire.getMovil());
        final String ID = fire.getID();

        rowView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(fContext, fire.getDate(), Toast.LENGTH_SHORT).show();
                PopupMenu menu = new PopupMenu(fContext, rowView);
                menu.inflate(R.menu.menu_layout);
                menu.show();

                menu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getTitle().equals(fContext.getString(R.string.strMap))){
                            SharedPreferences preferences = fContext.getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
                            String city = preferences.getString(PREF_CITY, fContext.getString(R.string.strCity));
                            String country = preferences.getString(PREF_COUNTRY, fContext.getString(R.string.strCountry));
                            if (city.equals(fContext.getString(R.string.strCity)) || TextUtils.isEmpty(city)) {
                                Toast.makeText(fContext, fContext.getString(R.string.strCityMissing), Toast.LENGTH_SHORT).show();
                            }
                            else if (country.equals(fContext.getString(R.string.strCountry)) || TextUtils.isEmpty(country)){
                                Toast.makeText(fContext, fContext.getString(R.string.strCountryMissing), Toast.LENGTH_SHORT).show();
                            }
                            else {
                                String addressStr = tvDomicilio.getText().toString().replaceAll(" ", "+");
                                addressStr += "+" + city + "+" + country;
                                Uri uri = Uri.parse("https://www.google.com/maps/place/" + addressStr); // missing 'http://' will cause crash
                                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                                fContext.startActivity(intent);
                            }
                        }
                        else {
                            AlertDialog.Builder builder = new AlertDialog.Builder(fContext);
                            builder.setMessage(fContext.getString(R.string.strConfirmEliminar));
                            builder.setCancelable(true);

                            builder.setPositiveButton(fContext.getString(R.string.strSi), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Fire fire = new Fire();
                                    fire.setID(ID);
                                    SQLiteHelper helper = new SQLiteHelper(fContext);
                                    helper.deleteRecord(fire);
                                    dialog.cancel();
                                    Intent intent = new Intent(fContext, DisplayActivity.class);
                                    fContext.startActivity(intent);
                                }
                            });

                            builder.setNegativeButton(fContext.getString(R.string.strNo), new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });

                            AlertDialog alert = builder.create();
                            alert.show();
                        };

                        return false;
                    }
                });
                return true;
            }
        });

        return rowView;
    }
}

