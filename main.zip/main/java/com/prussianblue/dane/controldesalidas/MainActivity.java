package com.prussianblue.dane.controldesalidas;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.icu.text.SimpleDateFormat;
import android.net.Uri;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{
    private static final String PREFS_NAME = "prefs";
    private static final String PREF_THEME = "theme";
    private static final String PREF_LANG = "lang";
    private static final String PREF_CITY = "city";
    private static final String PREF_COUNTRY = "country";
    private static final String PREF_EMAIL = "email";


    public TextView tvDate;
    public EditText txtPrevio;
    public EditText txtSalida;
    public EditText txtEntrada;
    public EditText txtDomicilio;
    public EditText txtAfeccion;
    public EditText txtACargo;
    public EditText txtChofer;
    public EditText txtMovil;
    public Button btnAnadir;
    public Button btnMostrar;
    SQLiteHelper helper = new SQLiteHelper(MainActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String pageTheme = preferences.getString(PREF_THEME, "red");
        final String pageLang = preferences.getString(PREF_LANG, "en");

        //Sets language and theme color
        PageSettings ps = new PageSettings();
        ps.setPageColor(this, pageTheme);
        ps.setPageLanguage(this, pageLang);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        tvDate = (TextView)findViewById(R.id.tvDate);
        final String dispDate;

        if (pageLang.equals("es")) {
            dispDate = new SimpleDateFormat("dd / MM / yyyy").format(new Date());
        } else {
            dispDate = new SimpleDateFormat("MM / dd / yyyy").format(new Date());
        }
        tvDate.setText(dispDate);

        tvDate.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    tvDate.setTextColor(getColor(R.color.colorPrimary));
                }
                else if (event.getAction() == MotionEvent.ACTION_UP ||
                        event.getAction() == MotionEvent.ACTION_CANCEL) {
                    tvDate.setTextColor(getColor(R.color.colorPrimaryDark));
                }
                return false;
            }
        });

        tvDate.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                DialogFragment newFragment = new DateMainFragment();
                newFragment.show(getSupportFragmentManager(), "datePicker");
                return false;
            }
        });

        txtPrevio = (EditText)findViewById(R.id.txtPrevio);
        txtSalida = (EditText)findViewById(R.id.txtSalida);
        txtEntrada = (EditText)findViewById(R.id.txtEntrada);
        txtDomicilio = (EditText)findViewById(R.id.txtDomicilio);
        txtAfeccion = (EditText)findViewById(R.id.txtAfeccion);
        txtACargo = (EditText)findViewById(R.id.txtACargo);
        txtChofer = (EditText)findViewById(R.id.txtChofer);
        txtMovil = (EditText)findViewById(R.id.txtMovil);
        btnAnadir = (Button)findViewById(R.id.btnAnadir);
        btnMostrar = (Button)findViewById(R.id.btnMostrar);

        btnAnadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strSalida = txtSalida.getText().toString().replaceAll("[^0-9]","");
                String strEntrada = txtEntrada.getText().toString().replaceAll("[^0-9]","");
                if (txtPrevio.getText().toString().equals("") || txtSalida.getText().toString().equals("") ||
                        txtEntrada.getText().toString().equals("") || txtDomicilio.getText().toString().equals("") ||
                        txtAfeccion.getText().toString().equals("") ||txtACargo.getText().toString().equals("") ||
                        txtChofer.getText().toString().equals("") ||txtMovil.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this, getString(R.string.strInfPerd), Toast.LENGTH_SHORT).show();
                }
                else if (Integer.parseInt(strSalida) < 0 ||
                        Integer.parseInt(strSalida) >2359 ||
                        Integer.parseInt(strEntrada) < 0 ||
                        Integer.parseInt(strEntrada) > 2359 ||
                        strSalida.length() != 4 ||
                        strEntrada.length() != 4 ||
                        Integer.parseInt(strSalida.substring(2,4)) > 59 ||
                        Integer.parseInt(strEntrada.substring(2,4)) > 59) {
                    Toast.makeText(MainActivity.this, getString(R.string.strHorInc), Toast.LENGTH_SHORT).show();
                }
                else {
                    Fire fire = new Fire();
                    int day;
                    int month;
                    int year;

                    if (pageLang=="en"){
                        month = Integer.valueOf(tvDate.getText().toString().substring(0,2));
                        day = Integer.valueOf(tvDate.getText().toString().substring(5,7));
                        year = Integer.valueOf(tvDate.getText().toString().substring(10));
                    }
                    else{
                        day = Integer.valueOf(tvDate.getText().toString().substring(0,2));
                        month = Integer.valueOf(tvDate.getText().toString().substring(5,7));
                        year = Integer.valueOf(tvDate.getText().toString().substring(10));
                    }

                    String date = year + "-" + month + "-" + day;

                    fire.setDate(date);
                    fire.setPrevio(txtPrevio.getText().toString());
                    fire.setHoraSalida(strSalida);
                    fire.setHoraEntrada(strEntrada);
                    fire.setDomicilio(txtDomicilio.getText().toString());
                    fire.setAfeccion(txtAfeccion.getText().toString());
                    fire.setACargo(txtACargo.getText().toString());
                    fire.setChofer(txtChofer.getText().toString());
                    fire.setMovil(txtMovil.getText().toString());
                    helper.insertFire(fire);

                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });

        btnMostrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home){
            return true;
        }
        else if (id == R.id.action_settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String eMail = preferences.getString(PREF_EMAIL, getString(R.string.strEmail));
        final String city = preferences.getString(PREF_CITY, getString(R.string.strCity));
        final String country = preferences.getString(PREF_COUNTRY, getString(R.string.strCountry));

        if (id == R.id.navCity){
            final EditText cityText = new EditText(this);
            if (city.equals(getString(R.string.strCity)) || TextUtils.isEmpty(city)) {
                cityText.setHint(getString(R.string.strCity));
            }
            else{
                cityText.setText(city);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strCity));
            builder.setView(cityText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_CITY, cityText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
        else if (id == R.id.navCountry){
            final EditText countryText = new EditText(this);
            if (country.equals(getString(R.string.strCountry)) || TextUtils.isEmpty(country)) {
                countryText.setHint(getString(R.string.strCountry));
            }
            else{
                countryText.setText(city);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strCountry));
            builder.setView(countryText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_COUNTRY, countryText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
        else if (id == R.id.navEmail){
            final EditText emailText = new EditText(this);

            if (eMail.equals(getString(R.string.strEmail)) || TextUtils.isEmpty(eMail)) {
                emailText.setHint(getString(R.string.strEmail));
            }
            else{
                emailText.setText(eMail);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strEmail));
            builder.setView(emailText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_EMAIL, emailText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
        else if (id == R.id.navSend) {
            DialogFragment newFragment = new DateEmailFragment();
            newFragment.show(getSupportFragmentManager(), "datePicker");
        }
        return true;
    }
}

