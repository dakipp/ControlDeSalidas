package com.prussianblue.dane.controldesalidas;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Build;

import java.util.Locale;

/**
 * Created by Dane on 11/26/2017.
 */

//Class to change settings on page
public class PageSettings {

    //changes theme color
    public void setPageColor(Activity activity, String color){
        if(color.equals("red")) {
            activity.setTheme(R.style.AppTheme_NoActionBar);
        }
        else if (color.equals("blue")){
            activity.setTheme(R.style.AltTheme_NoActionBar);
        }
        else if (color.equals("green")){
            activity.setTheme(R.style.AltTheme2_NoActionBar);
        }
    }

    //changes language
    public void setPageLanguage(Activity activity, String language){
        Locale locale = new Locale(language);
        Locale.setDefault(locale);
        Configuration config = activity.getBaseContext().getResources().getConfiguration();

        //based on SDK, some methods are deprecated
        if (Build.VERSION.SDK_INT <= 17){
            config.setLocale(locale);
            activity.getBaseContext().createConfigurationContext(config);
        }
        else {
            config.locale = locale;
            activity.getBaseContext().getResources().updateConfiguration(config, activity.getBaseContext().getResources().getDisplayMetrics());
        }
    }
}
