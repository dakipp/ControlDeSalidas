package com.prussianblue.dane.controldesalidas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.icu.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by Dane on 10/27/2017.
 */

public class SQLiteHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "SQLiteDatabase.db";
    public SQLiteHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static final String TABLE_NAME = "FIRES";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_DATE = "DATE";
    public static final String COLUMN_PREVIO = "PREVIO";
    public static final String COLUMN_HORA_SALIDA = "HORA_SALIDA";
    public static final String COLUMN_HORA_ENTRADA = "HORA_ENTRADA";
    public static final String COLUMN_DOMICILIO = "DOMICILIO";
    public static final String COLUMN_AFECCION = "AFECCION";
    public static final String COLUMN_A_CARGO = "A_CARGO";
    public static final String COLUMN_CHOFER = "CHOFER";
    public static final String COLUMN_MOVIL = "MOVIL";

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("create table " + TABLE_NAME + " ( " + COLUMN_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_DATE + " TEXT, " + COLUMN_PREVIO +
                " TEXT, " + COLUMN_HORA_SALIDA + " TEXT, " + COLUMN_HORA_ENTRADA + " TEXT, " +
                COLUMN_DOMICILIO + " TEXT, " + COLUMN_AFECCION + " TEXT, " + COLUMN_A_CARGO +
                " TEXT, " + COLUMN_CHOFER + " TEXT, " + COLUMN_MOVIL + " TEXT);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    private SQLiteDatabase database;

    public void insertFire(Fire fire) {
        database = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_DATE, fire.getDate());
        contentValues.put(COLUMN_PREVIO, fire.getPrevio());
        contentValues.put(COLUMN_HORA_SALIDA, fire.getHoraSalida());
        contentValues.put(COLUMN_HORA_ENTRADA, fire.getHoraEntrada());
        contentValues.put(COLUMN_DOMICILIO, fire.getDomicilio());
        contentValues.put(COLUMN_AFECCION, fire.getAfeccion());
        contentValues.put(COLUMN_A_CARGO, fire.getACargo());
        contentValues.put(COLUMN_CHOFER, fire.getChofer());
        contentValues.put(COLUMN_MOVIL, fire.getMovil());
        database.insert(TABLE_NAME, null, contentValues);
        database.close();
    }

    public void updateRecord(Fire fire) {
        database = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_DATE, fire.getDate());
        contentValues.put(COLUMN_PREVIO, fire.getPrevio());
        contentValues.put(COLUMN_HORA_SALIDA, fire.getHoraSalida());
        contentValues.put(COLUMN_HORA_ENTRADA, fire.getHoraEntrada());
        contentValues.put(COLUMN_DOMICILIO, fire.getDomicilio());
        contentValues.put(COLUMN_AFECCION, fire.getAfeccion());
        contentValues.put(COLUMN_A_CARGO, fire.getACargo());
        contentValues.put(COLUMN_CHOFER, fire.getChofer());
        contentValues.put(COLUMN_MOVIL, fire.getMovil());
        database.update(TABLE_NAME, contentValues, COLUMN_ID + " = ?", new String[]{fire.getID()});
        database.close();
    }

    public void deleteRecord(Fire fire) {
        database = this.getReadableDatabase();
        database.delete(TABLE_NAME, COLUMN_ID + " = ?", new String[]{fire.getID()});
        database.close();
    }

    public ArrayList<Fire> getAllRecords() {
        database = this.getReadableDatabase();
        Cursor cursor = database.query(TABLE_NAME, null, null, null, null, null, COLUMN_HORA_SALIDA);
        ArrayList<Fire> fires = new ArrayList<Fire>();
        Fire fire;
        if (cursor.getCount() > 0) {
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                fire = new Fire();
                fire.setID(cursor.getString(0));
                fire.setDate(cursor.getString(1));
                fire.setPrevio(cursor.getString(2));
                fire.setHoraSalida(cursor.getString(3));
                fire.setHoraEntrada(cursor.getString(4));
                fire.setDomicilio(cursor.getString(5));
                fire.setAfeccion(cursor.getString(6));
                fire.setACargo(cursor.getString(7));
                fire.setChofer(cursor.getString(8));
                fire.setMovil(cursor.getString(9));
                fires.add(fire);
            }
        }
        cursor.close();
        database.close();
        return fires;
    }

    public ArrayList<Fire> getRecordsForDay(String date) {
        database = this.getReadableDatabase();
        Cursor cursor = database.query(TABLE_NAME, null, "date='"+date+"'", null, null, null, COLUMN_HORA_SALIDA);
        ArrayList<Fire> fires = new ArrayList<Fire>();
        Fire fire;
        if (cursor.getCount() > 0) {
            for (int i = 0; i < cursor.getCount(); i++) {
                cursor.moveToNext();
                fire = new Fire();
                fire.setID(cursor.getString(0));
                fire.setDate(cursor.getString(1));
                fire.setPrevio(cursor.getString(2));
                fire.setHoraSalida(cursor.getString(3));
                fire.setHoraEntrada(cursor.getString(4));
                fire.setDomicilio(cursor.getString(5));
                fire.setAfeccion(cursor.getString(6));
                fire.setACargo(cursor.getString(7));
                fire.setChofer(cursor.getString(8));
                fire.setMovil(cursor.getString(9));
                fires.add(fire);
            }
        }
        cursor.close();
        database.close();
        return fires;
    }
}

