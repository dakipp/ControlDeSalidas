package com.prussianblue.dane.controldesalidas;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.support.annotation.IdRes;
import android.support.design.widget.NavigationView;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class SettingsActivity extends AppCompatActivity
    implements NavigationView.OnNavigationItemSelectedListener {
    private static final String PREFS_NAME = "prefs";
    private static final String PREF_THEME = "theme";
    private static final String PREF_LANG = "lang";
    private static final String PREF_CITY = "city";
    private static final String PREF_COUNTRY = "country";
    private static final String PREF_EMAIL = "email";

    RadioGroup rgLang;
    RadioButton rbEn;
    RadioButton rbEs;

    RadioGroup rgColor;
    RadioButton rbRed;
    RadioButton rbBlue;
    RadioButton rbGreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String pageTheme = preferences.getString(PREF_THEME, "red");
        String pageLang = preferences.getString(PREF_LANG, "en");

        //Sets language and theme color
        PageSettings ps = new PageSettings();
        ps.setPageColor(this, pageTheme);
        ps.setPageLanguage(this, pageLang);


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        rgLang = (RadioGroup)findViewById(R.id.rgLang);
        rbEn = (RadioButton)findViewById(R.id.rbEn);
        if (pageLang.equals("en")){
            rbEn.setChecked(true);
        }
        rbEs = (RadioButton)findViewById(R.id.rbEs);
        if (pageLang.equals("es")){
            rbEs.setChecked(true);
        }

        rgLang.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                String lang;
                SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();

                if (rbEn.isChecked()){
                    lang = "en";
                }
                else{
                    lang = "es";
                }

                editor.putString(PREF_LANG, lang);
                editor.apply();

                Intent intent = getIntent();
                finish();

                startActivity(intent);
            }
        });

        rgColor = (RadioGroup)findViewById(R.id.rgColor);
        rbRed = (RadioButton)findViewById(R.id.rbRed);
        if (pageTheme.equals("red")){
            rbRed.setChecked(true);
        }
        rbBlue = (RadioButton)findViewById(R.id.rbBlue);
        if (pageTheme.equals("blue")){
            rbBlue.setChecked(true);
        }
        rbGreen = (RadioButton)findViewById(R.id.rbGreen);
        if (pageTheme.equals("green")){
            rbGreen.setChecked(true);
        }

        rgColor.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                String theme;
                SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();

                if (rbRed.isChecked()){
                    theme = "red";
                }
                else if (rbBlue.isChecked()){
                    theme = "blue";
                }
                else{
                    theme = "green";
                }

                editor.putString(PREF_THEME, theme);
                editor.apply();

                Intent intent = getIntent();
                finish();

                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home){
            Intent intent = new Intent(SettingsActivity.this, MainActivity.class);
            startActivity(intent);
            return true;
        }
        else if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        final String eMail = preferences.getString(PREF_EMAIL, getString(R.string.strEmail));
        final String city = preferences.getString(PREF_CITY, getString(R.string.strCity));
        final String country = preferences.getString(PREF_COUNTRY, getString(R.string.strCountry));

        if (id == R.id.navCity){
            final EditText cityText = new EditText(this);
            if (city.equals(getString(R.string.strCity)) || TextUtils.isEmpty(city)) {
                cityText.setHint(getString(R.string.strCity));
            }
            else{
                cityText.setText(city);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strCity));
            builder.setView(cityText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_CITY, cityText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
        else if (id == R.id.navCountry){
            final EditText countryText = new EditText(this);
            if (country.equals(getString(R.string.strCountry)) || TextUtils.isEmpty(country)) {
                countryText.setHint(getString(R.string.strCountry));
            }
            else{
                countryText.setText(city);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strCountry));
            builder.setView(countryText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_COUNTRY, countryText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
        else if (id == R.id.navEmail){
            final EditText emailText = new EditText(this);

            if (eMail.equals(getString(R.string.strEmail)) || TextUtils.isEmpty(eMail)) {
                emailText.setHint(getString(R.string.strEmail));
            }
            else{
                emailText.setText(eMail);
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(this.getString(R.string.strEmail));
            builder.setView(emailText);
            builder.setCancelable(true);

            builder.setPositiveButton(getString(R.string.strConfirmar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                    editor.putString(PREF_EMAIL, emailText.getText().toString());
                    editor.apply();
                    dialog.cancel();
                }
            });

            builder.setNegativeButton(getString(R.string.strCancelar), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        } else if (id == R.id.navSend) {
            DialogFragment newFragment = new DateEmailFragment();
            newFragment.show(getSupportFragmentManager(), "datePicker");
        }
        return true;
    }
}
